All you have to do execute and run the cod is run the bash script (run.sh)
To do that, do the following (you might have to type "chmod +x run.sh" before step 1):

1.Type: ./run.sh 