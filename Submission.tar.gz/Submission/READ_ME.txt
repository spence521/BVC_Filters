All you have to do compile and run the code is to run the bash script (run.sh)
To do that, do the following:
(you might have to type "chmod +x run.sh" before step 2 but most likely not)

1. Extract the Submission.tar.gz on the Linux Cade Machine.
2. Type: ./run.sh in the "Submission" folder.